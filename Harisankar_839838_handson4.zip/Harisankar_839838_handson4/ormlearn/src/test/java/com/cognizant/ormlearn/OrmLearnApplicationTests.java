package com.cognizant.ormlearn;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrmLearnApplicationTests {

	
	

}
